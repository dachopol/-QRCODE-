package com.qrprom.th.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.FormatColorFill
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.QrCode
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Preset colors for QR code foreground (dots/pattern)
val QrDarkColorPresets = listOf(
    Pair("ดำคลาสสิก", Color(0xFF000000)),
    Pair("น้ำเงินเข้ม", Color(0xFF0B2853)),
    Pair("ฟ้าสดใส", Color(0xFF0284C7)),
    Pair("เขียวมรกต", Color(0xFF059669)),
    Pair("ม่วงเข้ม", Color(0xFF6D28D9)),
    Pair("แดงไวน์", Color(0xFF991B1B)),
    Pair("ส้มอิฐ", Color(0xFFC2410C)),
    Pair("ช็อกโกแลต", Color(0xFF451A03))
)

// Preset colors for QR code background (จุดเปลี่ยนสีพื้นหลัง)
val QrLightColorPresets = listOf(
    Pair("ขาวบริสุทธิ์", Color(0xFFFFFFFF)),
    Pair("ครีมงาช้าง", Color(0xFFFEF9C3)),
    Pair("ฟ้าพาสเทล", Color(0xFFE0F2FE)),
    Pair("เขียวมิ้นต์", Color(0xFFD1FAE5)),
    Pair("ชมพูซากุระ", Color(0xFFFCE7F3)),
    Pair("ส้มพีช", Color(0xFFFFEDD5)),
    Pair("ม่วงลาเวนเดอร์", Color(0xFFEDE9FE)),
    Pair("เหลืองอ่อน", Color(0xFFFEF08A)),
    Pair("เทาเงินโมเดิร์น", Color(0xFFE2E8F0)),
    Pair("ดำมินิมอล", Color(0xFF18181B))
)

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun QrColorCustomizerCard(
    darkColor: Color,
    lightColor: Color,
    onDarkColorChange: (Color) -> Unit,
    onLightColorChange: (Color) -> Unit,
    modifier: Modifier = Modifier
) {
    val isBgDark = lightColor == Color(0xFF18181B)

    Card(
        modifier = modifier
            .fillMaxWidth()
            .testTag("qr_color_customizer_card"),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(3.dp)
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header with title and reset button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(RoundedCornerShape(10.dp))
                            .background(Color(0xFF0284C7).copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = "ปรับแต่งสี",
                            tint = Color(0xFF0284C7),
                            modifier = Modifier.size(20.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "ปรับแต่งสี & จุดเปลี่ยนสีพื้นหลัง",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = Color(0xFF0F172A)
                        )
                        Text(
                            text = "เลือกสีลวดลายและสีพื้นหลังได้ตามต้องการ",
                            fontSize = 11.sp,
                            color = Color(0xFF64748B)
                        )
                    }
                }

                // Reset Button
                IconButton(
                    onClick = {
                        onDarkColorChange(Color.Black)
                        onLightColorChange(Color.White)
                    },
                    modifier = Modifier
                        .size(32.dp)
                        .testTag("reset_qr_colors_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Refresh,
                        contentDescription = "รีเซ็ตสีเริ่มต้น",
                        tint = Color(0xFF64748B),
                        modifier = Modifier.size(20.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // LIVE PREVIEW BADGE
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = lightColor,
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    if (isBgDark) Color(0xFF3F3F46) else Color(0xFFCBD5E1)
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 4.dp)
            ) {
                Row(
                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(28.dp)
                                .clip(RoundedCornerShape(6.dp))
                                .background(darkColor),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCode,
                                contentDescription = null,
                                tint = lightColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "แสดงผลสีแบบเรียลไทม์ (Live Preview)",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isBgDark) Color.White else Color(0xFF0F172A)
                            )
                            Text(
                                text = "จุดลาย: #${Integer.toHexString(darkColor.toArgb()).uppercase().takeLast(6)} | พื้นหลัง: #${Integer.toHexString(lightColor.toArgb()).uppercase().takeLast(6)}",
                                fontSize = 11.sp,
                                color = if (isBgDark) Color(0xFFA1A1AA) else Color(0xFF64748B)
                            )
                        }
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = (if (isBgDark) Color.White else Color(0xFF0F172A)).copy(alpha = 0.1f)
                    ) {
                        Text(
                            text = "พร้อมใช้งาน",
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = if (isBgDark) Color.White else Color(0xFF0F172A),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // SECTION 1: Background (Light) Color Selection - "จุดเปลี่ยนสีพื้นหลัง"
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.FormatColorFill,
                    contentDescription = null,
                    tint = Color(0xFF0284C7),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "จุดเปลี่ยนสีพื้นหลัง (Background):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                QrLightColorPresets.forEach { (name, color) ->
                    val isSelected = lightColor == color
                    val isDotWhite = color == Color.White || color == Color(0xFFFEF9C3)

                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable {
                                onLightColorChange(color)
                                // If user picked dark background and current darkColor is black, automatically switch darkColor to white for contrast
                                if (color == Color(0xFF18181B) && darkColor == Color.Black) {
                                    onDarkColorChange(Color.White)
                                } else if (color != Color(0xFF18181B) && darkColor == Color.White) {
                                    onDarkColorChange(Color.Black)
                                }
                            }
                            .testTag("color_light_${color.toArgb()}")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .shadow(2.dp, CircleShape)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (isSelected) 3.dp else 1.5.dp,
                                    color = if (isSelected) Color(0xFF0284C7) else (if (isDotWhite) Color(0xFFCBD5E1) else color.copy(alpha = 0.5f)),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = name,
                                    tint = if (color == Color(0xFF18181B)) Color.White else Color(0xFF0B2853),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = name.take(6),
                            fontSize = 9.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color(0xFF0284C7) else Color(0xFF64748B)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // SECTION 2: Foreground (Dark) Color Selection - "สีลวดลาย QR"
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.QrCode,
                    contentDescription = null,
                    tint = Color(0xFF0B2853),
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "สีลวดลายคิวอาร์ (Foreground QR):",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
            }
            Spacer(modifier = Modifier.height(8.dp))

            FlowRow(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                QrDarkColorPresets.forEach { (name, color) ->
                    val isSelected = darkColor == color
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clickable { onDarkColorChange(color) }
                            .testTag("color_dark_${color.toArgb()}")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(38.dp)
                                .shadow(2.dp, CircleShape)
                                .clip(CircleShape)
                                .background(color)
                                .border(
                                    width = if (isSelected) 3.dp else 1.dp,
                                    color = if (isSelected) Color(0xFF0284C7) else Color(0xFFCBD5E1),
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isSelected) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = name,
                                    tint = if (color == Color(0xFF000000) || color == Color(0xFF0B2853) || color == Color(0xFF451A03) || color == Color(0xFF991B1B) || color == Color(0xFF6D28D9)) Color.White else Color.Black,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = name.take(6),
                            fontSize = 9.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                            color = if (isSelected) Color(0xFF0284C7) else Color(0xFF64748B)
                        )
                    }
                }
            }
        }
    }
}
