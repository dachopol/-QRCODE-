package com.qrprom.th

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.toArgb
import com.qrprom.th.admob.AdMobManager
import com.qrprom.th.data.WalletManager
import com.qrprom.th.data.AppDatabase
import com.qrprom.th.data.MerchantProfileEntity
import com.qrprom.th.data.QrItemEntity
import com.qrprom.th.model.CardColorTheme
import com.qrprom.th.model.DigitalBusinessCard
import com.qrprom.th.model.ParsedQrResult
import com.qrprom.th.model.PromptPayModel
import com.qrprom.th.model.StoreLinkModel
import com.qrprom.th.model.StorePlatform
import com.qrprom.th.model.WifiModel
import com.qrprom.th.model.WifiSecurity
import com.qrprom.th.util.ImageExporter
import com.qrprom.th.util.PromptPayGenerator
import com.qrprom.th.util.QrCodeUtil
import com.qrprom.th.util.QrScannerUtil
import com.qrprom.th.util.QrValidationUtil
import com.qrprom.th.util.ValidationResult
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class ActiveQrPreview(
    val title: String,
    val subtitle: String,
    val rawContent: String,
    val qrBitmap: Bitmap,
    val standeeBitmap: Bitmap? = null,
    val targetId: String? = null,
    val amount: Double? = null,
    val type: String
)

class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AppDatabase.getDatabase(application)
    private val dao = db.qrDao()

    // Active bottom navigation tab: 0=Generate, 1=Card Studio, 2=Scanner, 3=History
    private val _currentTab = MutableStateFlow(0)
    val currentTab: StateFlow<Int> = _currentTab.asStateFlow()

    // Sub-tab under Generator: 0=PromptPay, 1=Wi-Fi, 2=Store Links, 3=Text
    private val _generatorCategory = MutableStateFlow(0)
    val generatorCategory: StateFlow<Int> = _generatorCategory.asStateFlow()

    // PromptPay State
    private val _promptPayTarget = MutableStateFlow("")
    val promptPayTarget: StateFlow<String> = _promptPayTarget.asStateFlow()

    private val _promptPayAmount = MutableStateFlow("")
    val promptPayAmount: StateFlow<String> = _promptPayAmount.asStateFlow()

    private val _promptPayShopName = MutableStateFlow("")
    val promptPayShopName: StateFlow<String> = _promptPayShopName.asStateFlow()

    // Wi-Fi State
    private val _wifiSsid = MutableStateFlow("")
    val wifiSsid: StateFlow<String> = _wifiSsid.asStateFlow()

    private val _wifiPassword = MutableStateFlow("")
    val wifiPassword: StateFlow<String> = _wifiPassword.asStateFlow()

    private val _wifiSecurity = MutableStateFlow(WifiSecurity.WPA)
    val wifiSecurity: StateFlow<WifiSecurity> = _wifiSecurity.asStateFlow()

    private val _wifiHidden = MutableStateFlow(false)
    val wifiHidden: StateFlow<Boolean> = _wifiHidden.asStateFlow()

    // Store Link State
    private val _storePlatform = MutableStateFlow(StorePlatform.LINE_OA)
    val storePlatform: StateFlow<StorePlatform> = _storePlatform.asStateFlow()

    private val _storeValue = MutableStateFlow("")
    val storeValue: StateFlow<String> = _storeValue.asStateFlow()

    // Text State
    private val _rawText = MutableStateFlow("")
    val rawText: StateFlow<String> = _rawText.asStateFlow()

    // Digital Business Card State
    private val _businessCard = MutableStateFlow(
        DigitalBusinessCard(
            fullName = "",
            businessName = "",
            profession = "",
            phoneNumber = "",
            promptPayId = "",
            lineId = "",
            facebook = "",
            email = "",
            services = "",
            cardTheme = CardColorTheme.NAVY_BLUE
        )
    )
    val businessCard: StateFlow<DigitalBusinessCard> = _businessCard.asStateFlow()

    // Active Preview Modal
    private val _activePreview = MutableStateFlow<ActiveQrPreview?>(null)
    val activePreview: StateFlow<ActiveQrPreview?> = _activePreview.asStateFlow()

    // Scan Result Modal
    private val _activeScanResult = MutableStateFlow<ParsedQrResult?>(null)
    val activeScanResult: StateFlow<ParsedQrResult?> = _activeScanResult.asStateFlow()
    private var lastScannedRaw: String? = null
    private var lastScannedAt: Long = 0L

    // TopUp and Subscription Dialog
    private val _showTopUpDialog = MutableStateFlow(false)
    val showTopUpDialog: StateFlow<Boolean> = _showTopUpDialog.asStateFlow()

    // Ad Stats Dialog
    private val _showAdStats = MutableStateFlow(false)
    val showAdStats: StateFlow<Boolean> = _showAdStats.asStateFlow()

    // Support and Bug Report Dialog
    private val _showSupportSheet = MutableStateFlow(false)
    val showSupportSheet: StateFlow<Boolean> = _showSupportSheet.asStateFlow()

    // Language and Currency Dialog
    private val _showLanguageAndCurrencyDialog = MutableStateFlow(false)
    val showLanguageAndCurrencyDialog: StateFlow<Boolean> = _showLanguageAndCurrencyDialog.asStateFlow()

    private val _languageCurrencyInitialTab = MutableStateFlow(0)
    val languageCurrencyInitialTab: StateFlow<Int> = _languageCurrencyInitialTab.asStateFlow()

    // QR Code Custom Color State
    private val _qrForegroundColor = MutableStateFlow(Color.Black)
    val qrForegroundColor: StateFlow<Color> = _qrForegroundColor.asStateFlow()

    private val _qrBackgroundColor = MutableStateFlow(Color.White)
    val qrBackgroundColor: StateFlow<Color> = _qrBackgroundColor.asStateFlow()

    // History flows from Room - Lazily loaded on demand when user opens History tab
    val historyItems: StateFlow<List<QrItemEntity>> = dao.getAllQrItems()
        .catch { emit(emptyList()) }
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.Lazily,
            initialValue = emptyList()
        )

    init {
        // Initialize Wallet and Quota Manager
        WalletManager.initialize(application)

        // Asynchronously load stored profile on IO thread to avoid main thread startup latency
        viewModelScope.launch(Dispatchers.IO) {
            try {
                dao.getMerchantProfile().catch { }.collect { saved ->
                    if (saved != null) {
                        val theme = try {
                            CardColorTheme.valueOf(saved.cardTheme)
                        } catch (_: Exception) {
                            CardColorTheme.NAVY_BLUE
                        }
                        _businessCard.value = DigitalBusinessCard(
                            fullName = saved.fullName,
                            businessName = saved.businessName,
                            profession = saved.profession,
                            phoneNumber = saved.phoneNumber,
                            promptPayId = saved.promptPayId,
                            lineId = saved.lineId,
                            facebook = saved.facebook,
                            email = saved.email,
                            services = saved.services,
                            cardTheme = theme
                        )
                        if (saved.promptPayId.isNotBlank()) {
                            _promptPayTarget.value = saved.promptPayId
                        }
                        if (saved.businessName.isNotBlank()) {
                            _promptPayShopName.value = saved.businessName
                        }
                    }
                }
            } catch (_: Exception) { }
        }
    }

    fun setTab(index: Int) {
        _currentTab.value = index
    }

    fun setGeneratorCategory(index: Int) {
        _generatorCategory.value = index
    }

    fun setPromptPayTarget(target: String) {
        _promptPayTarget.value = target
    }

    fun setPromptPayAmount(amount: String) {
        _promptPayAmount.value = amount
    }

    fun setPromptPayShopName(name: String) {
        _promptPayShopName.value = name
    }

    fun setWifiSsid(ssid: String) {
        _wifiSsid.value = ssid
    }

    fun setWifiPassword(pass: String) {
        _wifiPassword.value = pass
    }

    fun setWifiSecurity(security: WifiSecurity) {
        _wifiSecurity.value = security
    }

    fun setWifiHidden(hidden: Boolean) {
        _wifiHidden.value = hidden
    }

    fun setStorePlatform(platform: StorePlatform) {
        _storePlatform.value = platform
    }

    fun setStoreValue(value: String) {
        _storeValue.value = value
    }

    fun setRawText(text: String) {
        _rawText.value = text
    }

    fun updateBusinessCard(card: DigitalBusinessCard) {
        _businessCard.value = card
    }

    fun saveBusinessCardProfile() {
        val card = _businessCard.value
        viewModelScope.launch(Dispatchers.IO) {
            dao.saveMerchantProfile(
                MerchantProfileEntity(
                    id = 1,
                    fullName = card.fullName,
                    businessName = card.businessName,
                    profession = card.profession,
                    phoneNumber = card.phoneNumber,
                    promptPayId = card.promptPayId,
                    lineId = card.lineId,
                    facebook = card.facebook,
                    email = card.email,
                    services = card.services,
                    cardTheme = card.cardTheme.name
                )
            )
            withContext(Dispatchers.Main) {
                Toast.makeText(getApplication(), "บันทึกโปรไฟล์นามบัตรเรียบร้อย", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun closePreview() {
        _activePreview.value = null
    }

    fun closeScanResult() {
        _activeScanResult.value = null
    }

    fun openTopUpDialog() {
        _showTopUpDialog.value = true
    }

    fun closeTopUpDialog() {
        _showTopUpDialog.value = false
    }

    fun openAdStats() {
        _showAdStats.value = true
    }

    fun closeAdStats() {
        _showAdStats.value = false
    }

    fun openSupportSheet() {
        _showSupportSheet.value = true
    }

    fun closeSupportSheet() {
        _showSupportSheet.value = false
    }

    fun openLanguageAndCurrencyDialog(initialTab: Int = 0) {
        _languageCurrencyInitialTab.value = initialTab
        _showLanguageAndCurrencyDialog.value = true
    }

    fun closeLanguageAndCurrencyDialog() {
        _showLanguageAndCurrencyDialog.value = false
    }

    fun setQrForegroundColor(color: Color) {
        _qrForegroundColor.value = color
    }

    fun setQrBackgroundColor(color: Color) {
        _qrBackgroundColor.value = color
    }

    /**
     * Production-safe gate. Core QR features remain available while real Google
     * Mobile Ads / Play Billing are not configured. This avoids showing a fake ad
     * or granting paid entitlements without a verified transaction.
     */
    private fun executeWithFreeOrVipPolicy(
        actionName: String,
        onExecute: () -> Unit
    ) {
        onExecute()
    }

    private fun showValidation(result: ValidationResult): Boolean {
        return when (result) {
            ValidationResult.Valid -> true
            is ValidationResult.Invalid -> {
                Toast.makeText(getApplication(), result.reason, Toast.LENGTH_LONG).show()
                false
            }
        }
    }

    private fun validateSelectedQrColors(): Boolean = showValidation(
        QrValidationUtil.checkColorContrast(
            _qrForegroundColor.value.toArgb(),
            _qrBackgroundColor.value.toArgb()
        )
    )

    private fun verifyQr(bitmap: Bitmap, content: String): Boolean {
        val result = QrValidationUtil.verifyGeneratedQrBitmap(bitmap, content)
        if (!result.isValid) {
            Toast.makeText(
                getApplication(),
                result.errorMessage ?: "QR ที่สร้างอ่านกลับไม่ได้ กรุณาลองเปลี่ยนสีหรือข้อมูล",
                Toast.LENGTH_LONG
            ).show()
        }
        return result.isValid
    }

    /**
     * Generate PromptPay QR
     */
    fun generatePromptPay() {
        val target = _promptPayTarget.value.trim()
        if (!showValidation(QrValidationUtil.validatePromptPayTarget(target))) return
        if (!showValidation(QrValidationUtil.validateAmount(_promptPayAmount.value))) return
        if (!validateSelectedQrColors()) return

        executeWithFreeOrVipPolicy("สร้าง QR พร้อมเพย์") {
            val amount = _promptPayAmount.value.toDoubleOrNull()
            val payload = PromptPayGenerator.generatePayload(target, amount)
            val qrBitmap = QrCodeUtil.generateQrBitmap(
                content = payload,
                size = 900,
                darkColor = _qrForegroundColor.value.toArgb(),
                lightColor = _qrBackgroundColor.value.toArgb()
            ) ?: run {
                Toast.makeText(getApplication(), "สร้าง QR ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                return@executeWithFreeOrVipPolicy
            }
            if (!verifyQr(qrBitmap, payload)) return@executeWithFreeOrVipPolicy
            val standeeBitmap = QrCodeUtil.createPromptPayStandeeBitmap(
                qrBitmap = qrBitmap,
                title = "THAI QR PAYMENT",
                targetId = target,
                amount = amount,
                merchantName = _promptPayShopName.value,
                backgroundColor = _qrBackgroundColor.value.toArgb()
            )

            // Consume quota only after real monetization is enabled
            if (WalletManager.MONETIZATION_ENABLED) WalletManager.consumeUsage()

            val amountStr = if (amount != null && amount > 0) "฿${String.format("%,.2f", amount)}" else "ไม่ระบุยอดเงิน"
            val subtitle = "เบอร์/เลขบัตร: $target ($amountStr)"

            _activePreview.value = ActiveQrPreview(
                title = "พร้อมเพย์ (PromptPay)",
                subtitle = subtitle,
                rawContent = payload,
                qrBitmap = qrBitmap,
                standeeBitmap = standeeBitmap,
                targetId = target,
                amount = amount,
                type = "PROMPTPAY"
            )

            // Save to History in Room
            viewModelScope.launch(Dispatchers.IO) {
                dao.insertQrItem(
                    QrItemEntity(
                        type = "PROMPTPAY",
                        title = "พร้อมเพย์ $amountStr",
                        subtitle = subtitle,
                        rawContent = payload,
                        targetId = target,
                        amount = amount,
                        isScan = false
                    )
                )
            }
        }
    }

    /**
     * Generate Wi-Fi QR
     */
    fun generateWifi() {
        val ssid = _wifiSsid.value.trim()
        if (!showValidation(QrValidationUtil.validateWifi(ssid, _wifiPassword.value, _wifiSecurity.value.code))) return
        if (!validateSelectedQrColors()) return

        executeWithFreeOrVipPolicy("สร้าง QR Wi-Fi") {
            val payload = QrCodeUtil.buildWifiPayload(
                ssid = ssid,
                pass = _wifiPassword.value,
                security = _wifiSecurity.value.code,
                isHidden = _wifiHidden.value
            )
            val qrBitmap = QrCodeUtil.generateQrBitmap(
                content = payload,
                size = 900,
                darkColor = _qrForegroundColor.value.toArgb(),
                lightColor = _qrBackgroundColor.value.toArgb()
            ) ?: run {
                Toast.makeText(getApplication(), "สร้าง QR ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                return@executeWithFreeOrVipPolicy
            }
            if (!verifyQr(qrBitmap, payload)) return@executeWithFreeOrVipPolicy

            if (WalletManager.MONETIZATION_ENABLED) WalletManager.consumeUsage()

            _activePreview.value = ActiveQrPreview(
                title = "Wi-Fi: $ssid",
                subtitle = "รหัสผ่าน: ${_wifiPassword.value.ifBlank { "(ไม่มี)" }}",
                rawContent = payload,
                qrBitmap = qrBitmap,
                type = "WIFI"
            )

            viewModelScope.launch(Dispatchers.IO) {
                dao.insertQrItem(
                    QrItemEntity(
                        type = "WIFI",
                        title = "Wi-Fi: $ssid",
                        subtitle = "รหัสผ่าน: ${_wifiPassword.value}",
                        rawContent = payload,
                        isScan = false
                    )
                )
            }
        }
    }

    /**
     * Generate Store Link QR
     */
    fun generateStoreLink() {
        val model = StoreLinkModel(_storePlatform.value, _storeValue.value)
        val fullUrl = model.fullUrl
        if (_storeValue.value.isBlank()) {
            Toast.makeText(getApplication(), "กรุณากรอกลิงก์หรือไอดีร้านค้า", Toast.LENGTH_SHORT).show()
            return
        }
        if (!showValidation(QrValidationUtil.validateUrl(fullUrl))) return
        if (!validateSelectedQrColors()) return

        executeWithFreeOrVipPolicy("สร้าง QR ลิงก์ร้านค้า") {
            val qrBitmap = QrCodeUtil.generateQrBitmap(
                content = fullUrl,
                size = 900,
                darkColor = _qrForegroundColor.value.toArgb(),
                lightColor = _qrBackgroundColor.value.toArgb()
            ) ?: run {
                Toast.makeText(getApplication(), "สร้าง QR ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                return@executeWithFreeOrVipPolicy
            }
            if (!verifyQr(qrBitmap, fullUrl)) return@executeWithFreeOrVipPolicy

            if (WalletManager.MONETIZATION_ENABLED) WalletManager.consumeUsage()

            _activePreview.value = ActiveQrPreview(
                title = "ลิงก์ร้าน ${_storePlatform.value.title}",
                subtitle = fullUrl,
                rawContent = fullUrl,
                qrBitmap = qrBitmap,
                type = "STORE_LINK"
            )

            viewModelScope.launch(Dispatchers.IO) {
                dao.insertQrItem(
                    QrItemEntity(
                        type = "STORE_LINK",
                        title = "ลิงก์ร้าน ${_storePlatform.value.title}",
                        subtitle = fullUrl,
                        rawContent = fullUrl,
                        isScan = false
                    )
                )
            }
        }
    }

    /**
     * Generate Text QR
     */
    fun generateText() {
        val text = _rawText.value.trim()
        if (text.isBlank()) {
            Toast.makeText(getApplication(), "กรุณากรอกข้อความ", Toast.LENGTH_SHORT).show()
            return
        }
        if (!validateSelectedQrColors()) return

        executeWithFreeOrVipPolicy("สร้าง QR ข้อความ") {
            val qrBitmap = QrCodeUtil.generateQrBitmap(
                content = text,
                size = 900,
                darkColor = _qrForegroundColor.value.toArgb(),
                lightColor = _qrBackgroundColor.value.toArgb()
            ) ?: run {
                Toast.makeText(getApplication(), "สร้าง QR ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                return@executeWithFreeOrVipPolicy
            }
            if (!verifyQr(qrBitmap, text)) return@executeWithFreeOrVipPolicy

            if (WalletManager.MONETIZATION_ENABLED) WalletManager.consumeUsage()

            _activePreview.value = ActiveQrPreview(
                title = "ข้อความ QR",
                subtitle = if (text.length > 40) text.take(40) + "..." else text,
                rawContent = text,
                qrBitmap = qrBitmap,
                type = "TEXT"
            )

            viewModelScope.launch(Dispatchers.IO) {
                dao.insertQrItem(
                    QrItemEntity(
                        type = "TEXT",
                        title = "ข้อความ",
                        subtitle = text.take(40),
                        rawContent = text,
                        isScan = false
                    )
                )
            }
        }
    }

    /**
     * Generate Digital Business Card vCard & PromptPay QR
     */
    fun generateBusinessCardPreview() {
        val card = _businessCard.value
        if (!showValidation(QrValidationUtil.validateBusinessCard(card.fullName.ifBlank { card.businessName }, card.phoneNumber))) return

        executeWithFreeOrVipPolicy("สร้าง QR นามบัตรดิจิทัล") {
            val noteContent = buildString {
                if (card.profession.isNotBlank()) append("บริการ: ${card.profession}\n")
                if (card.promptPayId.isNotBlank()) append("พร้อมเพย์: ${card.promptPayId}\n")
                if (card.lineId.isNotBlank()) append("LINE: ${card.lineId}\n")
                if (card.services.isNotBlank()) append("รายละเอียด: ${card.services}")
            }
            val vcard = QrCodeUtil.buildVCardPayload(
                fullName = card.fullName,
                org = card.businessName,
                title = card.profession,
                phone = card.phoneNumber,
                email = card.email,
                url = if (card.facebook.isNotBlank()) "https://facebook.com/${card.facebook}" else "",
                note = noteContent
            )

            val qrBitmap = QrCodeUtil.generateQrBitmap(
                content = vcard,
                size = 900,
                darkColor = card.cardTheme.primaryColorHex.toInt()
            ) ?: run {
                Toast.makeText(getApplication(), "สร้าง QR ไม่สำเร็จ", Toast.LENGTH_SHORT).show()
                return@executeWithFreeOrVipPolicy
            }
            if (!verifyQr(qrBitmap, vcard)) return@executeWithFreeOrVipPolicy

            if (WalletManager.MONETIZATION_ENABLED) WalletManager.consumeUsage()

            _activePreview.value = ActiveQrPreview(
                title = "นามบัตรดิจิทัล: ${card.businessName.ifBlank { card.fullName }}",
                subtitle = "${card.profession} • ${card.phoneNumber}",
                rawContent = vcard,
                qrBitmap = qrBitmap,
                type = "VCARD"
            )

            viewModelScope.launch(Dispatchers.IO) {
                dao.insertQrItem(
                    QrItemEntity(
                        type = "VCARD",
                        title = "นามบัตร: ${card.businessName.ifBlank { card.fullName }}",
                        subtitle = "${card.profession} | ${card.phoneNumber}",
                        rawContent = vcard,
                        isScan = false
                    )
                )
            }
        }
    }

    /**
     * Handles Scanned QR string (from Camera or Gallery)
     * Direct result without blocking ads!
     */
    fun onQrScanned(raw: String) {
        if (raw.isBlank()) return
        val now = System.currentTimeMillis()
        if (raw == lastScannedRaw && now - lastScannedAt < 2_000L) return
        if (_activeScanResult.value != null && raw == lastScannedRaw) return
        lastScannedRaw = raw
        lastScannedAt = now

        val parsed = QrScannerUtil.parseQrContent(raw)

        // Save scan to Room
        viewModelScope.launch(Dispatchers.IO) {
            dao.insertQrItem(
                QrItemEntity(
                    type = parsed.type.name,
                    title = parsed.title,
                    subtitle = parsed.subtitle,
                    rawContent = raw,
                    targetId = parsed.promptPayId,
                    amount = parsed.amount,
                    isScan = true
                )
            )
        }

        // Instant result presentation - no ads blocking!
        _activeScanResult.value = parsed
    }

    /**
     * Process image picked from gallery
     */
    fun scanImageUri(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            try {
                val inputStream = getApplication<Application>().contentResolver.openInputStream(uri)
                val bitmap = android.graphics.BitmapFactory.decodeStream(inputStream)
                inputStream?.close()

                if (bitmap != null) {
                    val decodedText = QrScannerUtil.decodeBitmap(bitmap)
                    withContext(Dispatchers.Main) {
                        if (decodedText != null) {
                            onQrScanned(decodedText)
                        } else {
                            Toast.makeText(getApplication(), "ไม่พบคิวอาร์โค้ดในรูปภาพที่เลือก", Toast.LENGTH_SHORT).show()
                        }
                    }
                } else {
                    withContext(Dispatchers.Main) {
                        Toast.makeText(getApplication(), "ไม่สามารถอ่านไฟล์รูปภาพนี้ได้", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    Toast.makeText(getApplication(), "เกิดข้อผิดพลาดในการอ่านรูปภาพ", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }

    /**
     * User action to Save QR or Standee Bitmap.
     * Direct fast saving without intrusive blocking ads!
     */
    fun requestSaveBitmap(bitmap: Bitmap, title: String) {
        val uri = ImageExporter.saveBitmapToGallery(getApplication(), bitmap, title)
        if (uri != null) {
            Toast.makeText(
                getApplication(),
                "บันทึกรูปภาพลงอัลบั้มสำเร็จ (Pictures/QRprom)",
                Toast.LENGTH_LONG
            ).show()
        } else {
            Toast.makeText(getApplication(), "ไม่สามารถบันทึกรูปภาพได้", Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Delete item from History
     */
    fun deleteHistoryItem(item: QrItemEntity) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.deleteQrItem(item)
        }
    }

    /**
     * Clear all scans or generated items
     */
    fun clearHistory(isScan: Boolean) {
        viewModelScope.launch(Dispatchers.IO) {
            dao.clearHistory(isScan)
        }
    }
}
