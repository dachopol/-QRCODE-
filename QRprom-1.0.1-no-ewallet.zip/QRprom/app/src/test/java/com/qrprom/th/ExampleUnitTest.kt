package com.qrprom.th

import org.junit.Assert.*
import org.junit.Test

/**
 * Example local unit test, which will execute on the development machine (host).
 *
 * See [testing documentation](http://d.android.com/tools/testing).
 */
class ExampleUnitTest {
  @Test(expected = IllegalArgumentException::class)
  fun walletTargetCannotBeEncodedAsPhone() {
    com.qrprom.th.util.PromptPayGenerator.generatePayload("123456789012345", null)
  }

  @Test(expected = IllegalArgumentException::class)
  fun formattedWalletTargetIsAlsoRejected() {
    com.qrprom.th.util.PromptPayGenerator.generatePayload("12345-67890-12345", null)
  }

  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }
}
