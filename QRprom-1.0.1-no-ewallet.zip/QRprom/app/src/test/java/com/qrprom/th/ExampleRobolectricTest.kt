package com.qrprom.th

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun walletInputShowsValidationError() {
    listOf("123456789012345", "12345-67890-12345").forEach {
      org.junit.Assert.assertTrue(
        com.qrprom.th.util.QrValidationUtil.validatePromptPayTarget(it) is
          com.qrprom.th.util.ValidationResult.Invalid
      )
    }
    org.junit.Assert.assertTrue(
      com.qrprom.th.util.QrValidationUtil.validatePromptPayTarget("0812345678") is
        com.qrprom.th.util.ValidationResult.Valid
    )
  }

  @Test
  fun `non finite amounts are rejected`() {
    listOf("NaN", "Infinity", "-Infinity").forEach {
      org.junit.Assert.assertTrue(
        com.qrprom.th.util.QrValidationUtil.validateAmount(it) is
          com.qrprom.th.util.ValidationResult.Invalid
      )
    }
  }

  @Test
  fun `decoded QR must match requested content`() {
    val bitmap = requireNotNull(com.qrprom.th.util.QrCodeUtil.generateQrBitmap("actual-content"))
    org.junit.Assert.assertTrue(
      com.qrprom.th.util.QrValidationUtil.verifyGeneratedQrBitmap(bitmap, "actual-content").isValid
    )
    org.junit.Assert.assertFalse(
      com.qrprom.th.util.QrValidationUtil.verifyGeneratedQrBitmap(bitmap, "different-content").isValid
    )
  }

  @Test
  fun `app name is QRprom`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    assertEquals("QRprom", context.getString(R.string.app_name))
  }

  @Test
  fun `promptpay payload generation contains required EMVCo fields`() {
    val payload = com.qrprom.th.util.PromptPayGenerator.generatePayload("0812345678", 150.0)
    org.junit.Assert.assertTrue(payload.startsWith("000201"))
    org.junit.Assert.assertTrue(payload.contains("0016A000000677010111"))
    org.junit.Assert.assertTrue(payload.contains("5303764"))
    org.junit.Assert.assertTrue(payload.contains("5406150.00"))
    org.junit.Assert.assertTrue(payload.contains("6304"))
  }

  @Test
  fun `wifi payload generation format`() {
    val payload = com.qrprom.th.util.QrCodeUtil.buildWifiPayload("MyWiFi", "secret123", "WPA", false)
    assertEquals("WIFI:S:MyWiFi;T:WPA;P:secret123;H:false;;", payload)
  }

  @Test
  fun `localization switches languages`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    com.qrprom.th.util.LocalizationManager.initialize(context)
    val th = com.qrprom.th.util.LocalizationManager.ALL_LANGUAGES.first { it.code == "th" }
    com.qrprom.th.util.LocalizationManager.setLanguage(th)
    assertEquals("สร้าง QR", com.qrprom.th.util.LocalizationManager.getString("nav_generate"))
    val en = com.qrprom.th.util.LocalizationManager.ALL_LANGUAGES.first { it.code == "en" }
    com.qrprom.th.util.LocalizationManager.setLanguage(en)
    assertEquals("Generate QR", com.qrprom.th.util.LocalizationManager.getString("nav_generate"))
  }

  @Test
  fun `root security manager updates state`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val result = com.qrprom.th.util.RootSecurityManager.verifyDeviceIntegrity(context)
    assertEquals(result, com.qrprom.th.util.RootSecurityManager.rootState.value)
  }
}
