rootProject.name = "qrprom-wrapper-bootstrap"
