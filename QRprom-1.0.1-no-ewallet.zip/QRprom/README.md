# QRprom (Android)

Native Android app built with Kotlin + Jetpack Compose.

## Identity
- App name: QRprom
- Application ID / package: `com.qrprom.th`
- Version: `1.0.1` (versionCode 2)
- targetSdk: 36

## Open locally
1. Install Android Studio with Android SDK 36.
2. Open this project folder.
3. Let Gradle sync dependencies.
4. Run the debug build on a physical Android device for camera testing.

## Release notes
- This export does not include a Gradle wrapper (`gradlew`) or a release upload keystore.
- Real Google Mobile Ads and Google Play Billing are intentionally not simulated. Core QR features remain usable while monetization is not configured.
- Before publishing, configure Play Billing/AdMob with real Play Console products/ad units and test them on a release candidate.
- Build the signed Android App Bundle only with the upload key associated with the Play Console app `com.qrprom.th`.

Developer credit: AnakinYoo

See START_HERE_TH.md for external build and upload instructions.
