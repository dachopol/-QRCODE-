# QRprom — งานแก้ภายนอก AI Studio

## ค่าของชุดนี้
- App: QRprom
- Developer: AnakinYoo
- applicationId / namespace: com.qrprom.th
- versionName: 1.0.1
- versionCode: 2
- compileSdk / targetSdk: 36

ภาพ Play Console ยืนยันว่ามี QRprom (com.qrprom.th) แยกจาก QuickQR Business (com.aistudio.qrgenerator.kmpzqr)
ชุดนี้สำหรับ QRprom เท่านั้น การแก้ ZIP ไม่ได้เปลี่ยนโปรเจกต์บน AI Studio โดยอัตโนมัติ
ข้อผิดพลาด code 1 ซ้ำในภาพเป็นของ QuickQR Business ไม่ใช่หลักฐานเลขล่าสุดของ QRprom
ก่อนอัปโหลดตรวจว่า QRprom ยังไม่เคยใช้ code 2 ถ้าเคยใช้แล้วเพิ่ม versionCode ให้มากกว่าเลขที่ใช้ไปทั้งหมด
การแก้ช่อง Release name อย่างเดียวไม่เปลี่ยน versionCode ในไฟล์แอป

## ทำบนคอมพิวเตอร์โดยไม่ต้องใช้โควต้า AI Studio
1. แตก ZIP แล้วเปิดโฟลเดอร์ที่มี settings.gradle.kts ใน Android Studio
2. ใช้ JDK 17, Android SDK Platform 36, Build Tools 36.0.0 และ Gradle 9.3.1
3. ZIP เดิมไม่มี gradlew, gradlew.bat, gradle-wrapper.jar และชุดนี้ยังดาวน์โหลดเพิ่มไม่ได้
   ติดตั้ง Gradle 9.3.1 จาก https://gradle.org/releases/ แล้วเพิ่ม bin เข้า PATH
4. เปิด Terminal ที่โฟลเดอร์โปรเจกต์ รัน:

   gradle -p wrapper-bootstrap wrapper

   จากนั้นคัดลอก wrapper-bootstrap/gradlew, wrapper-bootstrap/gradlew.bat และ
   wrapper-bootstrap/gradle/wrapper/gradle-wrapper.jar ไปตำแหน่งเดียวกันที่รากโปรเจกต์
   ใช้ gradle/wrapper/gradle-wrapper.properties ที่มีอยู่แล้ว
5. Sync Gradle แล้วรันบน Windows:

   .\gradlew.bat :app:testDebugUnitTest :app:assembleDebug

   บน macOS/Linux:

   chmod +x gradlew
   ./gradlew :app:testDebugUnitTest :app:assembleDebug

6. ทดสอบ APK บนมือถือจริง โดยเฉพาะสิทธิ์กล้อง การสแกน สร้าง แชร์ และบันทึก QR
7. Android Studio: Build > Generate Signed Bundle / APK > Android App Bundle
   เลือก upload keystore ที่ตรงกับ QRprom ใน Play Console เก็บกุญแจและรหัสผ่านไว้ในเครื่อง
   หากยังไม่ทราบว่าบัญชีนี้เคยใช้กุญแจใด ให้ตรวจ App integrity ของ QRprom ก่อนลงนาม
8. เข้า Play Console > QRprom (com.qrprom.th) > การทดสอบภายใน > สร้างรุ่น
   อัปโหลด AAB ที่ลงนามแล้ว ไม่ใช่ ZIP ซอร์สโค้ด ตรวจคำเตือนก่อนส่งทดสอบ

## สถานะที่ยังไม่ผ่าน
- ยังไม่ได้ compile Kotlin, รัน unit tests, ทดสอบมือถือ หรือสร้าง APK/AAB ในสภาพแวดล้อมนี้
- การดาวน์โหลด Gradle ล้มเหลวจาก connection timeout และไม่มี Android SDK ติดตั้งอยู่
- ปิด e-Wallet 15 หลักแล้ว ทั้ง validation และ generator; เพิ่ม regression tests แต่ยังรันไม่ได้
- AdMob และ Billing ยังไม่ได้เชื่อมระบบจริง
- ไม่ยืนยันว่า AI Studio รองรับนำ ZIP กลับเข้าโปรเจกต์เดิม ให้ใช้ Android Studio สร้าง AAB จากชุดนี้

## เอกสารอ้างอิง
- https://developer.android.com/build/releases/agp-9-1-0-release-notes
- https://docs.gradle.org/current/userguide/gradle_wrapper.html
- https://developer.android.com/studio/publish/versioning
- https://developer.android.com/studio/publish/app-signing
