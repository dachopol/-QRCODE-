# QRprom project fix report

## Identity fixed
- App name: **QRprom**
- Package / applicationId: **com.qrprom.th**
- Namespace: **com.qrprom.th**
- Version: **1.0.1**
- versionCode: **2**
- targetSdk / compileSdk: **36**

## Code fixes made
- Renamed all Kotlin package declarations/imports from `com.example` and removed the old AI Studio package id.
- Removed old ZipQR / QuickQR branding from the project metadata and UI title.
- Moved source/test folders to `com/qrprom/th`.
- Removed obsolete test-mode/bypass references that would cause compilation errors.
- Updated Robolectric tests to match the current production APIs.
- Core QR features no longer depend on a simulated 30-second advertisement.
- Disabled unverified payment/ad-reward flows until real Google Play Billing / Google Mobile Ads are configured.
- Removed sample personal/business data from default form values.
- Added validation for PromptPay, Wi-Fi, URLs, business cards, QR color contrast, and QR self-decode after generation.
- Added scan de-duplication to reduce duplicate history entries.
- Added camera cleanup/error state handling and removed misleading scanner AdMob copy.
- Regenerated corrupted legacy launcher WebP files as valid PNG launcher assets.
- Added Play Store app icon asset at `play_store_assets/QRprom_app_icon_512.png`.
- Removed unused Gemini/Firebase configuration from the app module because no Firebase/Gemini implementation existed in the exported source.
- Release signing is now optional during local validation; signed Play upload still requires the real upload key.

## Static checks completed here
- XML resource parsing: passed.
- Kotlin/Kotlin-DSL bracket balance: passed.
- Old package/name/test-mode reference scan: passed for release source.
- Custom manager method reference scan: no unresolved custom API references found.
- Launcher image files: valid PNG files generated for mdpi/hdpi/xhdpi/xxhdpi/xxxhdpi.

## Not verified in this environment
A full Android Gradle build was **not run** because this environment does not contain Android SDK 36 or a complete Gradle wrapper executable/JAR from the original export. Do not claim the AAB is build-verified yet.

Before Play Console upload, open this project in Android Studio, sync Gradle, run unit tests, test the camera on a real phone, then build a signed AAB using the upload key associated with `com.qrprom.th`. Real AdMob and Play Billing must be configured with your own IDs/products before enabling monetization.

## Follow-up source review
- Fixed QR self-verification accepting decoded data different from the requested payload.
- Rejected non-finite amounts (NaN and infinity).
- Added regression tests for both cases, including an exact-match QR success case. These tests have NOT been executed here.
- XML parsing passed after the edits; this is not a Kotlin compilation or Android runtime test.
- Build still blocked: gradlew, gradlew.bat and gradle-wrapper.jar are absent, no installed Gradle or Android SDK was found. No APK/AAB was generated.
- Remaining finding: the validator accepts 15-digit wallet targets but the payload generator falls through to phone encoding. Wallet support needs a verified implementation before release.
- This is a limited source review, not a complete release certification.

## Play Console identity alignment
- Retained com.qrprom.th based on the user's actual Console screenshot.
- Updated versionName to 1.0.1 and versionCode to 2. The screenshot duplicate-code error belongs to the other QuickQR Business package; QRprom's latest uploaded code is not established.
- Added standalone wrapper generation configuration and Thai external-build guide. Wrapper binaries are NOT bundled; Gradle download attempt timed out.
- No remote AI Studio or Play Console changes performed. No AAB built or uploaded.

## e-Wallet disabled at user request
- Reject normalized 15-character wallet targets in validation with a clear Thai message.
- Generator independently rejects the same targets before phone conversion.
- Added raw/formatted wallet regression cases and retained-phone validation case (not executed: Android toolchain unavailable).
- Supersedes the earlier outstanding wallet-generation finding.
